
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;
import net.proteanit.sql.DbUtils;

public class Mlionner extends javax.swing.JFrame {

    public Mlionner() {
        initComponents();
        setSize(640, 425);
        connectionDB();
        homePanel.show();
        gamePanel.hide();
        aboutPanel.hide();
        gameOverPanel.hide();
        walamyRastPanel.hide();
        highScorePanel.hide();
        setLocation(400, 200);
        counterPanel.setBackground(new java.awt.Color(0, 204, 0, 100));

    }
    int u = 0;   // bo index arrayakay ka ID prsyarakany tyaya
    Connection objConn;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String[] answer = new String[4];
    String walamyRast = "";
    String namePlayer_str = "";
    int prsyarakanBaTekali[] = new int[20];
    int chrka = 31;
    int rexstn = 1;
    boolean chrkaBzhmerm = true;
    boolean bromaTimmer = true;
    boolean bromaTimmerPanel = true;
    String xalyBrawayPack = "";

    public void kat() {
        chrka = 31;
        chrkaBzhmerm = true;
        Timer myTimer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {

                if (chrkaBzhmerm == true) {
                    chrka--;
                    lblChrka.setText(chrka + "");
                }
                if (chrka == 0 && chrkaBzhmerm == true) {
                    chrkaBzhmerm = false;
                    chrka = 30;
                    lblChrka.setText(chrka + "");
                    gameOver();

                }

            }
        };

        if (bromaTimmer == true) {
            myTimer.schedule(task, 0, 1000);
            bromaTimmer = false;
        }

    }
    int move_panel = 0;
    boolean yakJarPrsyaryTaza = true;

    public void jwllayPanel() {
        move_panel = 0;
        yakJarPrsyaryTaza = true;
        Timer myTimer = new Timer();
        TimerTask task = new TimerTask() {
            @Override
            public void run() {

                if (move_panel < 19) {

                    counterPanel.setLocation(counterPanel.getLocation().x, counterPanel.getLocation().y - 1);
                } else if (yakJarPrsyaryTaza == true && move_panel == 40) {
                    walamyRastPanel.hide();
                    gamePanel.show();
                    question();
                    yakJarPrsyaryTaza = false;
                }
                move_panel++;

            }
        };

        if (bromaTimmerPanel == true) {
            myTimer.schedule(task, 0, 50);
            bromaTimmerPanel = false;
        }

    }

    void connectionDB() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/milionare";
            String user = "root";
            String password = "";
            objConn = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException t) {
            System.out.println("erroraka la connetiondaya :" + t);
        } catch (SQLException t) {
            System.out.println("erroraka la SQL :" + t);
        }
        if (objConn == null) {
            JOptionPane.showMessageDialog(null, "FailConnection");
        }

    }
    int rexstnyIdDb = 0;

    public void insertDataHigh(String parayXawen) {
        String sql = "insert into highscore (id,name,score) values (?,?,?)";
        long score = Long.parseLong(parayXawen);
        try {
            rexstnyIdDb++;
            ps = objConn.prepareStatement(sql);
            ps.setInt(1, rexstnyIdDb);
            ps.setString(2, namePlayer_str);
            ps.setLong(3, score);
            ps.executeUpdate();
        } catch (SQLException e) {
            insertDataHigh(xalyBrawayPack);        // bo away xoy indexy batal bbozetawa la dataBaseakada
        }
    }

    void question() {
        kat();
        String sql = "select * from question where id =?";

        try {
            ps = objConn.prepareStatement(sql);
            ps.setInt(1, prsyarakanBaTekali[u]);

            u++;
            if (u == 16) {
                gameOver();
                
            }

            rs = ps.executeQuery();
            while (rs.next()) {
                String que = rs.getString("question");
                answer[0] = rs.getString("A");
                answer[1] = rs.getString("b");
                answer[2] = rs.getString("C");
                answer[3] = rs.getString("D");
                walamyRast = rs.getString("A");
                question.setText(que);
            }
            String temp = "";
            for (int i = 0; i < answer.length; i++) {
                int ran = (int) (Math.random() * 3);
                temp = answer[i];
                answer[i] = answer[ran];
                answer[ran] = temp;
            }
            ansA.setText(answer[0]);
            ansB.setText(answer[1]);
            ansC.setText(answer[2]);
            ansD.setText(answer[3]);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        homePanel = new javax.swing.JPanel();
        playBtn = new javax.swing.JButton();
        aboutBtn = new javax.swing.JButton();
        highScoreBtn = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        gamePanel = new javax.swing.JPanel();
        question = new javax.swing.JLabel();
        ansA = new javax.swing.JLabel();
        ansC = new javax.swing.JLabel();
        ansB = new javax.swing.JLabel();
        ansD = new javax.swing.JLabel();
        lblChrka = new javax.swing.JLabel();
        backGround = new javax.swing.JLabel();
        highScorePanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        infoTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        aboutPanel = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        walamyRastPanel = new javax.swing.JPanel();
        counterPanel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        gameOverPanel = new javax.swing.JPanel();
        parayBrawa = new javax.swing.JLabel();
        namePlayer = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(null);

        homePanel.setLayout(null);

        playBtn.setFont(new java.awt.Font("Krmanj_A_HasanBag", 1, 18)); // NOI18N
        playBtn.setText("PLAY");
        playBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playBtnActionPerformed(evt);
            }
        });
        homePanel.add(playBtn);
        playBtn.setBounds(240, 200, 170, 30);

        aboutBtn.setFont(new java.awt.Font("Krmanj_A_HasanBag", 1, 18)); // NOI18N
        aboutBtn.setText("ABOUT");
        aboutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutBtnActionPerformed(evt);
            }
        });
        homePanel.add(aboutBtn);
        aboutBtn.setBounds(240, 320, 170, 30);

        highScoreBtn.setFont(new java.awt.Font("Krmanj_A_HasanBag", 1, 18)); // NOI18N
        highScoreBtn.setText("HIGH SCORE");
        highScoreBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                highScoreBtnActionPerformed(evt);
            }
        });
        homePanel.add(highScoreBtn);
        highScoreBtn.setBounds(240, 260, 170, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home.png"))); // NOI18N
        homePanel.add(jLabel1);
        jLabel1.setBounds(0, 0, 640, 400);

        getContentPane().add(homePanel);
        homePanel.setBounds(0, 0, 640, 400);

        gamePanel.setLayout(null);

        question.setFont(new java.awt.Font("Unikurd Chimen", 1, 18)); // NOI18N
        question.setForeground(new java.awt.Color(255, 255, 255));
        question.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        gamePanel.add(question);
        question.setBounds(60, 200, 500, 70);

        ansA.setFont(new java.awt.Font("Unikurd Chimen", 1, 18)); // NOI18N
        ansA.setForeground(new java.awt.Color(255, 255, 255));
        ansA.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        ansA.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ansA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ansAMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ansAMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ansAMouseExited(evt);
            }
        });
        gamePanel.add(ansA);
        ansA.setBounds(70, 290, 220, 40);

        ansC.setFont(new java.awt.Font("Unikurd Chimen", 1, 18)); // NOI18N
        ansC.setForeground(new java.awt.Color(255, 255, 255));
        ansC.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        ansC.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ansC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ansCMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ansCMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ansCMouseExited(evt);
            }
        });
        gamePanel.add(ansC);
        ansC.setBounds(70, 350, 220, 40);

        ansB.setFont(new java.awt.Font("Unikurd Chimen", 1, 18)); // NOI18N
        ansB.setForeground(new java.awt.Color(255, 255, 255));
        ansB.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        ansB.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ansB.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ansBMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ansBMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ansBMouseExited(evt);
            }
        });
        gamePanel.add(ansB);
        ansB.setBounds(340, 290, 220, 40);

        ansD.setFont(new java.awt.Font("Unikurd Chimen", 1, 18)); // NOI18N
        ansD.setForeground(new java.awt.Color(255, 255, 255));
        ansD.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        ansD.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ansD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ansDMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ansDMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ansDMouseExited(evt);
            }
        });
        gamePanel.add(ansD);
        ansD.setBounds(340, 350, 220, 40);

        lblChrka.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        lblChrka.setForeground(new java.awt.Color(255, 255, 255));
        lblChrka.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblChrka.setText("30");
        gamePanel.add(lblChrka);
        lblChrka.setBounds(290, 320, 50, 40);

        backGround.setFont(new java.awt.Font("Unikurd Mestan", 1, 18)); // NOI18N
        backGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/281ao1e.jpg"))); // NOI18N
        gamePanel.add(backGround);
        backGround.setBounds(0, 0, 640, 400);

        getContentPane().add(gamePanel);
        gamePanel.setBounds(0, 0, 640, 400);

        highScorePanel.setBackground(new java.awt.Color(0, 0, 0));
        highScorePanel.setLayout(null);

        infoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Name", "Score"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Long.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        infoTable.setRowHeight(30);
        jScrollPane1.setViewportView(infoTable);
        if (infoTable.getColumnModel().getColumnCount() > 0) {
            infoTable.getColumnModel().getColumn(0).setResizable(false);
            infoTable.getColumnModel().getColumn(1).setResizable(false);
        }

        highScorePanel.add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 520, 330);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home-icon.png"))); // NOI18N
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel7MouseClicked(evt);
            }
        });
        highScorePanel.add(jLabel7);
        jLabel7.setBounds(530, 0, 100, 100);

        getContentPane().add(highScorePanel);
        highScorePanel.setBounds(0, 0, 640, 400);

        aboutPanel.setLayout(null);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home-icon.png"))); // NOI18N
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel3MouseClicked(evt);
            }
        });
        aboutPanel.add(jLabel3);
        jLabel3.setBounds(0, 0, 100, 100);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/aboutMil.png"))); // NOI18N
        aboutPanel.add(jLabel2);
        jLabel2.setBounds(0, 0, 640, 400);

        getContentPane().add(aboutPanel);
        aboutPanel.setBounds(0, 0, 640, 400);

        walamyRastPanel.setLayout(null);

        counterPanel.setLayout(null);
        walamyRastPanel.add(counterPanel);
        counterPanel.setBounds(410, 380, 175, 20);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/walamyRast.png"))); // NOI18N
        walamyRastPanel.add(jLabel5);
        jLabel5.setBounds(0, -10, 650, 440);

        getContentPane().add(walamyRastPanel);
        walamyRastPanel.setBounds(0, 0, 640, 425);

        gameOverPanel.setBackground(new java.awt.Color(0, 0, 0));
        gameOverPanel.setForeground(new java.awt.Color(0, 102, 102));
        gameOverPanel.setLayout(null);

        parayBrawa.setFont(new java.awt.Font("Monotype Corsiva", 1, 18)); // NOI18N
        parayBrawa.setForeground(new java.awt.Color(0, 0, 0));
        parayBrawa.setText("1,000,000");
        gameOverPanel.add(parayBrawa);
        parayBrawa.setBounds(420, 180, 140, 12);

        namePlayer.setFont(new java.awt.Font("Monotype Corsiva", 1, 24)); // NOI18N
        namePlayer.setForeground(new java.awt.Color(0, 0, 0));
        namePlayer.setText("Marwan Qadr");
        gameOverPanel.add(namePlayer);
        namePlayer.setBounds(190, 170, 220, 30);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/home-icon.png"))); // NOI18N
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        gameOverPanel.add(jLabel6);
        jLabel6.setBounds(260, 300, 120, 90);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gameOver.png"))); // NOI18N
        gameOverPanel.add(jLabel4);
        jLabel4.setBounds(0, 0, 640, 400);

        getContentPane().add(gameOverPanel);
        gameOverPanel.setBounds(0, 0, 640, 400);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void ansBMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansBMouseClicked
        String walam = ansB.getText();
        if (walam.equals(walamyRast)) {
            gamePanel.hide();
            walamyRastPanel.show();
            jwllayPanel();

        } else {
            gameOver();
        }
    }//GEN-LAST:event_ansBMouseClicked

    private void ansAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansAMouseClicked
        String walam = ansA.getText();
        if (walam.equals(walamyRast)) {
            gamePanel.hide();
            walamyRastPanel.show();
            jwllayPanel();

        } else {
            gameOver();
        }
    }//GEN-LAST:event_ansAMouseClicked

    private void ansCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansCMouseClicked
        String walam = ansC.getText();
        if (walam.equals(walamyRast)) {
            gamePanel.hide();
            walamyRastPanel.show();
            jwllayPanel();

        } else {
            gameOver();
        }
    }//GEN-LAST:event_ansCMouseClicked

    private void ansDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansDMouseClicked
        String walam = ansD.getText();
        if (walam.equals(walamyRast)) {
            gamePanel.hide();
            walamyRastPanel.show();
            jwllayPanel();

        } else {
            gameOver();
        }
    }//GEN-LAST:event_ansDMouseClicked

    private void playBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playBtnActionPerformed

        for (;;) {

            namePlayer_str = JOptionPane.showInputDialog(null, "Please Enter The Name");
            if (!(namePlayer_str.equals(""))) {
                break;
            }
        }
        namePlayer.setText(namePlayer_str);
        homePanel.hide();
        gamePanel.show();
        newGame();

        question();

    }//GEN-LAST:event_playBtnActionPerformed

    public void newGame() {
        for (int i = 0; i < prsyarakanBaTekali.length; i++) {
            prsyarakanBaTekali[i] = i + 1;

        }

        int temp = 0;
        for (int i = 0; i < prsyarakanBaTekali.length; i++) {
            int ran = (int) (Math.random() * 5);
            temp = prsyarakanBaTekali[i];
            prsyarakanBaTekali[i] = prsyarakanBaTekali[ran];
            prsyarakanBaTekali[ran] = temp;
        }

    }

    public void gameOver() {
        namePlayer.setText(namePlayer_str);
        gamePanel.hide();
        gameOverPanel.show();
        counterPanel.setLocation(410, 380);
           chrkaBzhmerm = false;
        if (u == 1) {
            parayBrawa.setText("0");
        }
        if (u == 2) {
            parayBrawa.setText("100");
        }
        if (u == 3) {
            parayBrawa.setText("200");
        }
        if (u == 4) {
            parayBrawa.setText("300");
        }
        if (u == 5) {
            parayBrawa.setText("500");
        }
        if (u == 6) {
            parayBrawa.setText("1,000");
        }
        if (u == 7) {
            parayBrawa.setText("2,000");
        }
        if (u == 8) {
            parayBrawa.setText("4,000");
        }
        if (u == 9) {
            parayBrawa.setText("8,000");
        }
        if (u == 10) {
            parayBrawa.setText("16,000");
        }
        if (u == 11) {
            parayBrawa.setText("32000");
        }
        if (u == 12) {
            parayBrawa.setText("64,000");
        }
        if (u == 13) {
            parayBrawa.setText("125,000");
        }
        if (u == 14) {
            parayBrawa.setText("250,000");
        }
        if (u == 15) {
            parayBrawa.setText("500,00");
        }
        if (u == 16) {
            parayBrawa.setText("1,000,000");
        }
        u = 0;
        newGame();
        xalyBrawayPack = "";
        for (int i = 0; i < parayBrawa.getText().length(); i++) {
            if (parayBrawa.getText().charAt(i) >= 47 && parayBrawa.getText().charAt(i) < 58) {
                xalyBrawayPack = xalyBrawayPack + (parayBrawa.getText().charAt(i));
            }
        }
        insertDataHigh(xalyBrawayPack);   // am paramtaera bo nardny parakaya dway pakrdnaway la faryzaw sht
    }
    private void aboutBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutBtnActionPerformed
        homePanel.hide();
        aboutPanel.show();
    }//GEN-LAST:event_aboutBtnActionPerformed

    private void jLabel3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseClicked
        aboutPanel.hide();
        homePanel.show();
    }//GEN-LAST:event_jLabel3MouseClicked

    private void ansBMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansBMouseEntered
        ansB.setForeground(Color.orange);
    }//GEN-LAST:event_ansBMouseEntered

    private void ansBMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansBMouseExited
        ansB.setForeground(Color.white);
    }//GEN-LAST:event_ansBMouseExited

    private void ansAMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansAMouseEntered
        ansA.setForeground(Color.orange);
    }//GEN-LAST:event_ansAMouseEntered

    private void ansAMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansAMouseExited
        ansA.setForeground(Color.white);
    }//GEN-LAST:event_ansAMouseExited

    private void ansCMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansCMouseEntered
        ansC.setForeground(Color.orange);
    }//GEN-LAST:event_ansCMouseEntered

    private void ansCMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansCMouseExited
        ansC.setForeground(Color.WHITE);
    }//GEN-LAST:event_ansCMouseExited

    private void ansDMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansDMouseEntered
        ansD.setForeground(Color.orange);
    }//GEN-LAST:event_ansDMouseEntered

    private void ansDMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ansDMouseExited
        ansD.setForeground(Color.white);
    }//GEN-LAST:event_ansDMouseExited

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        homePanel.show();
        gameOverPanel.hide();
        gameOverPanel.hide();
        homePanel.show();
    }//GEN-LAST:event_jLabel6MouseClicked

    private void highScoreBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_highScoreBtnActionPerformed
        homePanel.hide();
        highScorePanel.show();
        String sql = "select name,score from highscore order by score desc  limit 10 ";
        try {
            ps = objConn.prepareStatement(sql);
            rs = ps.executeQuery();
            infoTable.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_highScoreBtnActionPerformed

    private void jLabel7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel7MouseClicked
        highScorePanel.hide();
        homePanel.show();
    }//GEN-LAST:event_jLabel7MouseClicked

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Mlionner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Mlionner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Mlionner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Mlionner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Mlionner().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton aboutBtn;
    private javax.swing.JPanel aboutPanel;
    private javax.swing.JLabel ansA;
    private javax.swing.JLabel ansB;
    private javax.swing.JLabel ansC;
    private javax.swing.JLabel ansD;
    private javax.swing.JLabel backGround;
    private javax.swing.JPanel counterPanel;
    private javax.swing.JPanel gameOverPanel;
    private javax.swing.JPanel gamePanel;
    private javax.swing.JButton highScoreBtn;
    private javax.swing.JPanel highScorePanel;
    private javax.swing.JPanel homePanel;
    private javax.swing.JTable infoTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblChrka;
    private javax.swing.JLabel namePlayer;
    private javax.swing.JLabel parayBrawa;
    private javax.swing.JButton playBtn;
    private javax.swing.JLabel question;
    private javax.swing.JPanel walamyRastPanel;
    // End of variables declaration//GEN-END:variables
}
